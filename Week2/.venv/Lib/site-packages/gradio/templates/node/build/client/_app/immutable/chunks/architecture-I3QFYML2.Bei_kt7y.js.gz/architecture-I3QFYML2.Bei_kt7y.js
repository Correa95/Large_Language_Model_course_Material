import{A as c,e as t}from"./mermaid-parser.core.BaAwBCH5.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-I3QFYML2.Bei_kt7y.js.map

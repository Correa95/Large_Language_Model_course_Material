import{v as o}from"./2.2SL1dUyv.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.CEZzmsyl.js.map

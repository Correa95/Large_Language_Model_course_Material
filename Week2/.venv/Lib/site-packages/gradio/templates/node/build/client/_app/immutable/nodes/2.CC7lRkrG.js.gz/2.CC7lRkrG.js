import{Z as e,_ as n}from"../chunks/2.2SL1dUyv.js";export{e as component,n as universal};
//# sourceMappingURL=2.CC7lRkrG.js.map

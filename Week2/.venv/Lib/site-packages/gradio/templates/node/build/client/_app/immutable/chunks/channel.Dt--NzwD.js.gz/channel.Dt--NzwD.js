import{U as a,C as n}from"./mermaid.core.Zs5WOViL.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.Dt--NzwD.js.map
